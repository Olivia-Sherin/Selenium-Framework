##### **Getting Started:**

1. Frame work required JAVA 1.8 and Above.
2. TestNG in IntelliJ IDEA.
3. MS-Excel.


##### **Execution Process:**

1.	Open excel Datasheet.xlsx and navigate to testdata worksheet
2.	Enter the following values (FieldName,Locator,DataValue)
3.  Navigate to config worksheet and Enter browser value,application url,screenShot

